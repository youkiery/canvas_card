export class Card {
  id: number;
  value: number;
  rank: number;
  x: number;
  y: number;
  selected: boolean
}